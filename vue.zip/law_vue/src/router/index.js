import Vue from 'vue'
import VueRouter from 'vue-router'

//后台管理页面
import MyRegister from "@/pager/MyRegister";
import myLogin from "@/pager/MyLogin";
import myAdmin from "@/pager/admin/MyAdmin";
import MyAdmins from "@/pager/admin/MyAdmins";
import MyUsers from "@/pager/admin/MyUsers";
import MyLawyers from "@/pager/admin/MyLawyers";
import MyLegals from "@/pager/admin/MyLegal";

//用户页面
import UserNews from "@/pager/user/UserNews";
import UserIndexs from "@/pager/user/UserIndexs";
import UserLawyers from "@/pager/user/UserLawyers";
import UserQuestions from "@/pager/user/UserQuestions";
import UserMsg from "@/pager/user/UserMsg";

import UserPager from "@/pager/user/UserPager";

Vue.use(VueRouter)

const routes = [
    {
        path: '/',
        name: 'MyLogin',
        component: myLogin
    },
    {
        path: "/register",
        name: 'register',
        component: MyRegister,
    },
    {
        path: "/admin",
        name: 'myAdmin',
        component: myAdmin,
        children: [
            {
                path: '/admins',
                name: 'admins',
                component: MyAdmins
            },
            {
                path: '/users',
                name: 'users',
                component: MyUsers
            },
            {
                path: '/lawyers',
                name: 'lawyers',
                component: MyLawyers
            },
            {
                path: '/legals',
                name: 'legals',
                component: MyLegals
            }
        ]
    },
    {
        path: "/user",
        name: 'user',
        component: UserPager,
        redirect: '/indexs',
        children: [
            {
                path: '/indexs',
                name: "indexs",
                component: UserIndexs
            },
            {
                path: '/news',
                name: "news",
                component: UserNews
            },
            {
                path: '/lawyerTeams',
                name: "lawyerTeams",
                component: UserLawyers
            },
            {
                path: "/msgs",
                name: "msgs",
                component: UserMsg
            },
            {
                path: "/questions",
                name: "questions",
                component: UserQuestions
            }
        ]
    }
]

const router = new VueRouter({
    routes
})

export default router
