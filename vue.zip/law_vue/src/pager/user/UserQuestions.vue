<template>
  <div></div>
</template>

<script>
export default {
  name: "UserQuestions"
}
</script>

<style scoped>

</style>