<template>
  <div></div>
</template>

<script>
export default {
  name: "UserMsg"
}
</script>

<style scoped>

</style>