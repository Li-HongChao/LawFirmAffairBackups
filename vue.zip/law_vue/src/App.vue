<template>
 <router-view></router-view>
</template>

<script>


</script>

<style>

body {
  height: 100%;
  width: 100%;
  background: url(./assets/bg.png) no-repeat fixed center center;
  background-size: cover;
  /*overflow: hidden;*/
  margin: 0;
  padding: 0;
}
body::-webkit-scrollbar {
  display: none;
}

</style>
